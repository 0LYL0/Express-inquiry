//
//  OtherViewController.m
//  快递查询
//
//  Created by 刘雅兰 on 2017/6/14.
//  Copyright © 2017年 刘雅兰. All rights reserved.
//

#import "OtherViewController.h"
#import "SecondViewController.h"
@interface OtherViewController ()

@end

@implementation OtherViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIColor *testColor= [UIColor colorWithRed:150/255.0 green:200/255.0 blue:255/255.0 alpha:1];
    
    //A开头
    UILabel *A = [[UILabel alloc]initWithFrame:CGRectMake(20, 80, 10, 20)];
    [A setText:@"A"];
    [A setFont:[UIFont systemFontOfSize:10]];
    [A setBackgroundColor:[UIColor greenColor]];
    [self.view addSubview:A];
    
    //中通
    UIButton *anxinda = [[UIButton alloc]initWithFrame:CGRectMake(40, 80, 70, 20)];
    [anxinda setTitle:@"安信达快递" forState:UIControlStateNormal];
    anxinda.titleLabel.font = [UIFont systemFontOfSize:10];
    [anxinda setBackgroundColor:testColor];
    [anxinda addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [anxinda setTag:1];
    [self.view addSubview:anxinda];
    
    
    
    //天天
    UIButton *anjie = [[UIButton alloc]initWithFrame:CGRectMake(120, 80, 70, 20)];
    [anjie setTitle:@"安捷快递" forState:UIControlStateNormal];
    anjie.titleLabel.font = [UIFont systemFontOfSize:10];
    [anjie setBackgroundColor:testColor];
    [anjie addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [anjie setTag:2];
    [self.view addSubview:anjie];
    
    
    //B开头
    UILabel *B = [[UILabel alloc]initWithFrame:CGRectMake(20, 110, 10, 20)];
    [B setText:@"B"];
    [B setFont:[UIFont systemFontOfSize:10]];
    [B setBackgroundColor:[UIColor greenColor]];
    [self.view addSubview:B];
    
    
    
    //彪记
    UIButton *biaoji = [[UIButton alloc]initWithFrame:CGRectMake(40, 110, 70, 20)];
    [biaoji setTitle:@"彪记快递" forState:UIControlStateNormal];
    biaoji.titleLabel.font = [UIFont systemFontOfSize:10];
    [biaoji setBackgroundColor:testColor];
    [biaoji addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [biaoji setTag:3];
    [self.view addSubview:biaoji];
    
    
    
    //BNT
    UIButton *bnt = [[UIButton alloc]initWithFrame:CGRectMake(120, 110, 70, 20)];
    [bnt setTitle:@"BNT" forState:UIControlStateNormal];
    bnt.titleLabel.font = [UIFont systemFontOfSize:10];
    [bnt setBackgroundColor:testColor];
    [bnt addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [bnt setTag:4];
    [self.view addSubview:bnt];
    
    
    
    //C开头
    UILabel *C  = [[UILabel alloc]initWithFrame:CGRectMake(20, 140, 10, 20)];
    [C  setText:@"C"];
    [C setFont:[UIFont systemFontOfSize:10]];
    [C setBackgroundColor:[UIColor greenColor]];
    [self.view addSubview:C];
    
    
    
    
    //COE
    UIButton *coe = [[UIButton alloc]initWithFrame:CGRectMake(40, 140, 70, 20)];
    [coe setTitle:@"COE" forState:UIControlStateNormal];
    coe.titleLabel.font = [UIFont systemFontOfSize:10];
    [coe setBackgroundColor:testColor];
    [coe addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [coe setTag:5];
    [self.view addSubview:coe];
    
    
    
    
    //长宇
    UIButton *changyu = [[UIButton alloc]initWithFrame:CGRectMake(120, 140, 70, 20)];
    [changyu setTitle:@"长宇快递" forState:UIControlStateNormal];
    changyu.titleLabel.font = [UIFont systemFontOfSize:10];
    [changyu setBackgroundColor:testColor];
    [changyu addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [changyu setTag:6];
    [self.view addSubview:changyu];
    
    
    
    //Y开头
    UILabel *Y  = [[UILabel alloc]initWithFrame:CGRectMake(20, 170, 10, 20)];
    [Y  setText:@"Y"];
    [Y setFont:[UIFont systemFontOfSize:10]];
    [Y setBackgroundColor:[UIColor greenColor]];
    [self.view addSubview:Y];
    
    
    
    //亚风
    UIButton *yafeng = [[UIButton alloc]initWithFrame:CGRectMake(40, 170, 50, 20)];
    [yafeng setTitle:@"亚风快递" forState:UIControlStateNormal];
    yafeng.titleLabel.font = [UIFont systemFontOfSize:10];
    [yafeng setBackgroundColor:testColor];
    [yafeng addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [yafeng setTag:7];
    [self.view addSubview:yafeng];
    
    
    
    
    //一邦
    UIButton *yibang = [[UIButton alloc]initWithFrame:CGRectMake(95, 170, 50, 20)];
    [yibang setTitle:@"一邦快递" forState:UIControlStateNormal];
    yibang.titleLabel.font = [UIFont systemFontOfSize:10];
    [yibang setBackgroundColor:testColor];
    [yibang addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [yibang setTag:8];
    [self.view addSubview:yibang];
    
    
    
    
    //优速
    UIButton *yousu = [[UIButton alloc]initWithFrame:CGRectMake(150, 170, 50, 20)];
    [yousu setTitle:@"优速快递" forState:UIControlStateNormal];
    yousu.titleLabel.font = [UIFont systemFontOfSize:10];
    [yousu setBackgroundColor:testColor];
    [yousu addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [yousu setTag:9];
    [self.view addSubview:yousu];
    
    
    
    
    //远成
    UIButton *yuancheng = [[UIButton alloc]initWithFrame:CGRectMake(205, 170, 50, 20)];
    [yuancheng setTitle:@"远成快递" forState:UIControlStateNormal];
    yuancheng.titleLabel.font = [UIFont systemFontOfSize:10];
    [yuancheng setBackgroundColor:testColor];
    [yuancheng addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [yuancheng setTag:10];
    [self.view addSubview:yuancheng];
    
    
    
    
    //源伟丰
    UIButton *yuanweifeng = [[UIButton alloc]initWithFrame:CGRectMake(260, 170, 70, 20)];
    [yuanweifeng setTitle:@"源伟丰快递" forState:UIControlStateNormal];
    yuanweifeng.titleLabel.font = [UIFont systemFontOfSize:10];
    [yuanweifeng setBackgroundColor:testColor];
    [yuanweifeng addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [yuanweifeng setTag:11];
    [self.view addSubview:yuanweifeng];
    
    
    
    
    //运通
    UIButton *yuntong = [[UIButton alloc]initWithFrame:CGRectMake(40, 200, 50, 20)];
    [yuntong setTitle:@"运通快递" forState:UIControlStateNormal];
    yuntong.titleLabel.font = [UIFont systemFontOfSize:10];
    [yuntong setBackgroundColor:testColor];
    [yuntong addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [yuntong setTag:11];
    [self.view addSubview:yuntong];
    
    
    
    
    //自己输入
    UIButton *other = [[UIButton alloc]initWithFrame:CGRectMake(30, 380, 300, 60)];
    [other setTitle:@"其他快递" forState:UIControlStateNormal];
    [other setBackgroundColor:testColor];
    [other addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [other setTag:100];
    [self.view addSubview:other];
    
    
    // Do any additional setup after loading the view.
}

- (void)click:(UIButton *)button
{
    SecondViewController *viewScend = [[SecondViewController alloc] init];
    
    
    viewScend.title = @"查询";
    
    switch ([button tag]) {
        case 1:
            [viewScend companyName:@"anxinda" withChinese:@"安信达快递"];
            break;
        case 2:
            [viewScend companyName:@"anjie" withChinese:@"安捷快递"];
            break;
        case 3:
            [viewScend companyName:@"biaoji" withChinese:@"彪记快递"];
            break;
        case 4:
            [viewScend companyName:@"bnt" withChinese:@"BNT"];
            break;
        case 5:
            [viewScend companyName:@"coe" withChinese:@"COE"];
            break;
        case 6:
            [viewScend companyName:@"changyu" withChinese:@"长宇快递"];
            break;
        case 7:
            [viewScend companyName:@"yafeng" withChinese:@"亚风快递"];
            break;
        case 8:
            [viewScend companyName:@"yibang" withChinese:@"一邦快递"];
            break;
        case 9:
            [viewScend companyName:@"yousu" withChinese:@"优速快递"];
            break;
        case 10:
            [viewScend companyName:@"yuancheng" withChinese:@"远成快递"];
            break;
        case 11:
            [viewScend companyName:@"yuntong" withChinese:@"运通快递"];
            break;
        case 100:
            [viewScend companyName:@"" withChinese:@""];
            break;
            
    }
    [self.navigationController pushViewController:viewScend animated:YES];
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
