//
//  SecondViewController.h
//  快递查询
//
//  Created by 刘雅兰 on 2017/6/14.
//  Copyright © 2017年 刘雅兰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController
{
    UITextField *setNumber;
    UITextField *setName;
}

@property(nonatomic,retain)NSString *comName;


- (void)companyName:(NSString *)name withChinese:(NSString *)chinese;
@end
