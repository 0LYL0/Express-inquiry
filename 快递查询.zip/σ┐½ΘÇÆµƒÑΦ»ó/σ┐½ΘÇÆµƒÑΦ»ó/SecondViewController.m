//
//  SecondViewController.m
//  快递查询
//
//  Created by 刘雅兰 on 2017/6/14.
//  Copyright © 2017年 刘雅兰. All rights reserved.
//

#import "SecondViewController.h"
#import "ThirdViewController.h"
@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)companyName:(NSString *)name withChinese:(NSString *)chinese{
    NSLog(@"%@,%@",name,chinese);
    
    self.comName = name;
    
    [self viewOfInput:name addChinese:chinese];
}


- (void)viewOfInput:(NSString *)comName addChinese:cName{
    
    //label公司名
    UILabel *name=[[UILabel alloc]initWithFrame:CGRectMake(20, 150, 60, 50)];
    [name setTextColor:[UIColor blackColor]];
    [name setBackgroundColor:[UIColor clearColor]];
    [name setText:@"公司名"];
    
    //label运单号
    UILabel *number=[[UILabel alloc]initWithFrame:CGRectMake(20, 200, 60, 50)];
    [number setTextColor:[UIColor blackColor]];
    [number setBackgroundColor:[UIColor clearColor]];
    [number setText:@"运单号"];
    
    [self.view addSubview:name];
    [self.view addSubview:number];
    
    //textField输入公司名称
    setName=[[UITextField alloc]initWithFrame:CGRectMake(80, 160,200, 30)];
    [setName setBackgroundColor:[UIColor whiteColor]];
    [setName setPlaceholder:@"输入快递名 如：yunda"];
    
    
    //setName.
    [setName setText:cName];
    [setName setTextColor:[UIColor grayColor]];
    [setName setBorderStyle:UITextBorderStyleRoundedRect];
    [setName setFont:[UIFont systemFontOfSize:18]];
    [setName resignFirstResponder];
    setName.delegate = (id)self;
    
    
    
    //textField输入运单号
    setNumber=[[UITextField alloc]initWithFrame:CGRectMake(80,210, 200, 30)];
    [setNumber setBackgroundColor:[UIColor whiteColor]];
    [setNumber setPlaceholder:@"输入运单号"];
    [setNumber setBorderStyle:UITextBorderStyleRoundedRect];
    [setNumber setReturnKeyType:UIReturnKeyDone];
    [setNumber setTextColor:[UIColor greenColor]];
    [setNumber setFont:[UIFont systemFontOfSize:18]];
    setNumber.delegate = (id)self;
    
    [self.view addSubview:setNumber];
    [self.view addSubview:setName];
    
    
    UIColor *testColor= [UIColor colorWithRed:150/255.0 green:200/255.0 blue:255/255.0 alpha:1];
    
    
    //查询按钮
    UIButton *buttonOne = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    buttonOne.frame=CGRectMake(90, 260, 150, 50);
    [buttonOne setBackgroundColor:testColor];
    [buttonOne setTitle:@"查询" forState:UIControlStateNormal];
    buttonOne.titleLabel.font = [UIFont systemFontOfSize:20];
    [buttonOne setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    //[buttonOne setBackgroundImage:[UIImage imageNamed:@"search"] forState:UIControlStateNormal];
    [buttonOne addTarget:self action:@selector(clic:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:buttonOne];
    
    
}



-(void)resume{
    [self.view setFrame:CGRectMake(0, 0, 320, 480)];
}




-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [setName resignFirstResponder];
    [setNumber resignFirstResponder];
}




#pragma mark texfiledDelegte
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == setNumber) {
        [self.view setFrame:CGRectMake(0, -40, 320, 480)];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    [self resume];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    [textField resignFirstResponder];
    [self resume];
}



//点击后的方法
-(void)clic:(UIButton *)button{
    
    ThirdViewController *viewThird = [[ThirdViewController alloc] init];
    
    //viewScend.view.backgroundColor=[UIColor greenColor];
    
    [viewThird flashDataWithName:self.comName withNumber:[setNumber text]];
    
    viewThird.title = @"查询结果";
    
    [self.navigationController pushViewController:viewThird animated:YES];
    
    
}





- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
