//
//  ThirdViewController.h
//  快递查询
//
//  Created by 刘雅兰 on 2017/6/14.
//  Copyright © 2017年 刘雅兰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController
@property(nonatomic)NSMutableData *receiveData;
@property(nonatomic)NSURLRequest *request;
@property(nonatomic)UIColor *testColor;
@property(nonatomic)UILabel *lableWrong;
- (void)flashDataWithName:(NSString *)strName withNumber:(NSString *)strNum;
- (void)showInView:(NSArray *)dic;

@end
