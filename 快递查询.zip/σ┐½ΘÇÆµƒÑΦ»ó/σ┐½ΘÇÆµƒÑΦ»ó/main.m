//
//  main.m
//  快递查询
//
//  Created by 刘雅兰 on 2017/6/7.
//  Copyright © 2017年 刘雅兰. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
