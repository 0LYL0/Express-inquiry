//
//  FirstViewController.m
//  快递查询
//
//  Created by 刘雅兰 on 2017/6/14.
//  Copyright © 2017年 刘雅兰. All rights reserved.
//

#import "FirstViewController.h"

#import "SecondViewController.h"
#import "OtherViewController.h"
@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)loadView{
    [super loadView];
    UIColor *testColor= [UIColor colorWithRed:150/255.0 green:200/255.0 blue:255/255.0 alpha:1];
    self.view.backgroundColor = testColor;
    [self select];
    
}

- (void)select{
    
    //韵达
    yunda = [[UIButton alloc]initWithFrame:CGRectMake(30, 100, 140, 50)];
    [yunda setBackgroundImage:[UIImage imageNamed:@"yunda"] forState:UIControlStateNormal];
    [yunda setTag:1];
    [yunda addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:yunda];
    
    
    //EMS
    ems = [[UIButton alloc]initWithFrame:CGRectMake(205, 100, 140, 50)];
    [ems setBackgroundImage:[UIImage imageNamed:@"EMS"] forState:UIControlStateNormal];
    [ems setTag:2];
    [ems addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:ems];
    
    
    //圆通
    yuantong = [[UIButton alloc]initWithFrame:CGRectMake(30, 195, 140, 50)];
    [yuantong setBackgroundImage:[UIImage imageNamed:@"yuantong"] forState:UIControlStateNormal];
    [yuantong setTag:3];
    [yuantong addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:yuantong];
    
    
    
    //申通
    shentong = [[UIButton alloc]initWithFrame:CGRectMake(205, 195, 140, 50)];
    [shentong setBackgroundImage:[UIImage imageNamed:@"shentong"] forState:UIControlStateNormal];
    [shentong setTag:4];
    [shentong addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:shentong];
    
    

    //顺丰
    shunfeng = [[UIButton alloc]initWithFrame:CGRectMake(30, 280, 140, 50)];
    [shunfeng setBackgroundImage:[UIImage imageNamed:@"shunfeng"] forState:UIControlStateNormal];
    [shunfeng setTag:5];
    [shunfeng addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:shunfeng];
    
    
    
    //天天
    tiantian = [[UIButton alloc]initWithFrame:CGRectMake(205, 280, 140, 50)];
    [tiantian setBackgroundImage:[UIImage imageNamed:@"tiantian"] forState:UIControlStateNormal];
    [tiantian setTag:6];
    [tiantian addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:tiantian];
    
    
    
    
    //其他
    more = [[UIButton alloc]initWithFrame:CGRectMake(35, 380, 300, 60)];
    [more setBackgroundColor:[UIColor greenColor]];
    [more setTitle:@"更多快递..." forState:UIControlStateNormal];
    [more setTag:7];
    [more addTarget:self action:@selector(clickTwo:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:more];
    
    
}
- (void)click:(UIButton *)buton{
    
    SecondViewController *viewScend = [[SecondViewController alloc] init];
    
    
    viewScend.title = @"查询";
    
    switch ([buton tag]) {
        case 1:
            [viewScend companyName:@"yunda" withChinese:@"韵达快递"];
            break;
        case 2:
            [viewScend companyName:@"ems" withChinese:@"EMS"];
            break;
        case 3:
            [viewScend companyName:@"yuantong" withChinese:@"圆通快递"];
            break;
        case 4:
            [viewScend companyName:@"shentong" withChinese:@"申通快递"];
            break;
        case 5:
            [viewScend companyName:@"shunfeng" withChinese:@"顺丰快递"];
            break;
        case 6:
            [viewScend companyName:@"tiantian" withChinese:@"天天快递"];
            break;
            
            
    }
    
    
    
    [self.navigationController pushViewController:viewScend animated:YES];
    
}


- (void)clickTwo:(UIButton *)button{
    
    OtherViewController *viewOfOther = [[OtherViewController alloc]init];
    
    viewOfOther.title = @"其他快递";
    
    [self.navigationController pushViewController:viewOfOther animated:YES];
    
}




- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
