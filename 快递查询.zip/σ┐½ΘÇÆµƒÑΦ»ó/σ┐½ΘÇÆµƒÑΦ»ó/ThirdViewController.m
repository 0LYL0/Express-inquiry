//
//  ThirdViewController.m
//  快递查询
//
//  Created by 刘雅兰 on 2017/6/14.
//  Copyright © 2017年 刘雅兰. All rights reserved.
//

#import "ThirdViewController.h"

@interface ThirdViewController ()
@property NSMutableDictionary *array;
@end

@implementation ThirdViewController

- (void)flashDataWithName:(NSString *)strName withNumber:(NSString *)strNum{
    
    NSString *urlName = [[NSString alloc]init];
    NSString *urltext = [[NSString alloc]init];
    NSString *urlNum = [[NSString alloc]init];
    
    NSLog(@"urlNum=%@",urlNum);
    
    if(!(strName == urltext)){
        urlName = [NSString stringWithFormat:@"?company=%@",strName];
    }
    
    if(!(strNum == urltext)){
        urlNum = [NSString stringWithFormat:@"&id=%@",strNum];
    }
    
    
    NSString *strUrl = [NSString stringWithFormat:@"http://www.kuaidi100.com/query?type=%@&postid=%@",strName,strNum];
    NSURL *urlOne = [NSURL URLWithString:strUrl];
    self.request = [NSURLRequest requestWithURL:urlOne];
    NSData *data=[NSData dataWithContentsOfURL:urlOne];
    NSDictionary *Dict=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
     NSLog(@"%@",Dict);
    
    

    NSURLSession *session=[NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask=[session dataTaskWithRequest:self.request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        _array=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
        if (error) {
            NSLog(@"error:%@",error.description);
        }
        else
        {
        }
    }];
    [dataTask resume];
    [self showInView:Dict];

}




#pragma mark - NSURLConnectionDataDelegate
//收到服务器回应的时候调用此方法
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    
    _receiveData=[NSMutableData alloc];
}


//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [_receiveData appendData:data];
}


//请求完之后调用
- (void)connectionDidFinishLoading:(NSURLConnection *)connection{
    
    UIColor *testColor= [UIColor colorWithRed:150/255.0 green:200/255.0 blue:255/255.0 alpha:0.3];
    
    _lableWrong = [[UILabel alloc]initWithFrame:CGRectMake(50, 150, 220, 100)];
    [_lableWrong setTextAlignment:NSTextAlignmentCenter];
    _lableWrong.backgroundColor = testColor;
    _lableWrong.numberOfLines = 0;

    NSLog(@"connectionDidFinishLoading");
    NSString *infoString = [[NSString alloc]initWithData:_receiveData encoding:NSUTF8StringEncoding];
    NSLog(@"返回的json数据为:%@",infoString);
    //返回信息处理
    if ([infoString isEqualToString:@"null"]) {
        NSLog(@"查询成功但运单过期或没有物流信息");
        
        _lableWrong.text = @"查询成功但运单过期或没有物流信息";
        [self.view addSubview:_lableWrong];
    }
    else if([infoString isEqualToString:@"Param_Error"]){
        NSLog(@"缺少参数");
        
        _lableWrong.text = @"缺少参数";
        [self.view addSubview:_lableWrong];
    }
    else if([infoString isEqualToString:@"Illegal_ID"]){
        NSLog(@"运单号或快递公司编码无效");
        
        _lableWrong.text = @"运单号或快递公司编码无效";
        [self.view addSubview:_lableWrong];
        
    }
    else if([infoString isEqualToString:@"Server_Error"]){
        NSLog(@"服务其错误");
        
        _lableWrong.text = @"运单号或快递公司编码无效";
        [self.view addSubview:_lableWrong];
        
    }
    else{
        NSLog(@"成功");
        NSArray *array = [NSJSONSerialization JSONObjectWithData:_receiveData options: NSJSONReadingAllowFragments  error:nil];
        
        [self showInView:array];
    }
}



- (void)showInView:(NSDictionary *)array{
    
    NSArray *data=[array valueForKey:@"data"];
     NSLog(@"%@",data);
    int i=0;
    for (NSDictionary *dic in data) {
        UILabel *showTime = [[UILabel alloc]initWithFrame:CGRectMake(10, 65+i*30, 30, 15)];
                    [showTime setFont:[UIFont fontWithName:Nil size:10]];
                    [showTime setTextColor:[UIColor grayColor]];
                    [showTime setText:@"时间："];
                    [self.view addSubview:showTime];
        
                    //lable显示状态
                    UILabel *showDetail = [[UILabel alloc]initWithFrame:CGRectMake(10, 80+i*30, 30, 15)];
                    [showDetail setFont:[UIFont fontWithName:nil size:10]];
                    [showDetail setTextColor:[UIColor greenColor]];
                    [showDetail setText:@"状态："];
                    [self.view addSubview:showDetail];
        
                    //label显示具体时间
                    showTime = [[UILabel alloc]initWithFrame:CGRectMake(40, 65+i*30,320, 15)];
                    [showTime setFont:[UIFont fontWithName:nil size:10]];
                    [showTime setBackgroundColor:[UIColor redColor]];
                    [showTime setText:[dic objectForKey:@"time"]];
                    [self.view addSubview:showTime];
        
                    //lable显示具体状态
                    showDetail = [[UILabel alloc]initWithFrame:CGRectMake(40, 80+i*30, 320, 15)];
                    [showDetail setFont:[UIFont fontWithName:nil size:10]];
                    [showDetail setBackgroundColor:[UIColor greenColor]];
                    [showDetail setText:[dic objectForKey:@"context"]];
                    [self.view addSubview:showDetail];
                    
                    
                    
                    i++;
                    

    }
    

}
    







@end
